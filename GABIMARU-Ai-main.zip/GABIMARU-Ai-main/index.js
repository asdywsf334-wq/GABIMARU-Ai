import { Client } from "meowsab";
import { subBots, subs } from "./system/sub.js";
import "meowsab/safe";
import "./system/database.js";
import * as baileys from "baileys";
import notifications from "./system/notifications.js";
import path from "node:path";

/* ========== Client Config ======== */

const client = new Client({
  // commands
  plugsdir: "plugins",
  prefix: [".", "!"],

  // baileys
  library: [baileys],

  // session
  sessionStorage: {
    type: "sqlite",          
    path: "./session",
  },

  // pairing code
  login: {
    method: "pair",
    number: "201115079442",
    code: "GABIMARU",
  },

  // owners
  owners: [
    { jid: "966575252858@s.whatsapp.net", lid: "269144427626750@lid" },
    { jid: "966567158348@s.whatsapp.net", lid: "230919638098013@lid" },
    { jid: "201066826750@s.whatsapp.net", lid: "247579682029763@lid" },
    { lid: "1838246064203@lid" },
    { jid: "201027439894@s.whatsapp.net", lid: "140656605450455@lid" },
    { username: "T7_14" },  
  ],

  // control settings
  settings: {
    message_owner_only: false,
    private_mode: false,
    message_group_only: false,
    no_message_baileys: false,
    from_me: false,
  },
});

/* ========== Config Info ======== */

const { config } = client;

config.info = {
  nameBot: "𝙂𝘼𝘽𝙄𝙈𝘼𝙍𝙐𝐁𝐨𝐭",
  title: "𝙂𝘼𝘽𝙄𝙈𝘼𝙍𝙐 — 🎀 | 𝐁𝐨𝐭 𝐢𝐬 𝐛𝐮𝐢𝐥𝐭 𝐨𝐧 𝐭𝐡𝐞 𝐌𝐄𝐎𝐖𝐒𝐀𝐁 𝐅𝐫𝐚𝐦𝐞𝐰𝐨𝐫𝐤",
  channel: {
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363225356834044@newsletter",
      newsletterName: "𝙂𝘼𝘽𝙄𝙈𝘼𝙍𝙐 ~ 📌",
      serverMessageId: 0,
    },
  },
  newsletter: {
    name: "𝙂𝘼𝘽𝙄𝙈𝘼𝙍𝙐 ~ 📌",
    jid: "120363225356834044@newsletter",
  },
  images: [
    "https://basepic.com/uQ7LxNDk/449200ffdeddc9d6ae32e42087a726c2.jpg",
    "https://basepic.com/XcUhTprA/93a22af25a04acb637a3b989de6f4b7d.jpg",
    "https://basepic.com/JtcFQ9SV/139ef8459fb79fa648ce1b93fee344e3.jpg",
    "https://basepic.com/FSkDZFcG/c9705ff1ef5946bee4bc26af87e2b4ac.jpg",
  ],
};

/* ========== Send the error to owner ======== */

const conn = client.sock;
const owner = client.owners?.[0]?.jid;

client.on("error", async (err) => {
  if (!conn || !owner) return;

  const errorText = String(err?.stack || err?.message || err).slice(0, 3500);

  try {
    await conn.sendMessage(owner, { text: errorText });
  } catch (e) {
    console.error("Failed to send error:", e);
  }
});

/* ========== Notification ======== */

const plugins = client.plug();
plugins.notification(notifications);

/* ========== Starting ======== */

const start = async () => {
  await client.connect();
  await subBots(client);
  await subs.start();
};

start().catch((err) => {
  console.error("❌ Startup error:", err.message);
});